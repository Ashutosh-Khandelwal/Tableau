Things I have done in Chicago Filming Project are as follows:

• Cleaning Data 
• Geolocation Data 
• Stories 
• Calculated Field
• Date Calculations
• If-Then statements
• Filtering Data
• Line Graphs